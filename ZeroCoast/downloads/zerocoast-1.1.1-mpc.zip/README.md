# ZeroCoast (wul) 1.1.1

A West-Coast semi-modular voice for the Akai MPC standalone, in the spirit of compact modular-style instruments. Original code and artwork; it is not affiliated
with, and contains nothing from, any hardware maker. 4 voices (or 1 gliding mono voice), 120 programs.

**Needs MPC OS 3.10.1 or later, with External Plugin Support enabled** (Preferences > Enhancements (Beta) > Enable Enhancements and External Plugin Support).
Copy the folder `wul - VST - ZeroCoast` into a `VST2 Plugins` folder on a drive.

## Signal path
Triangle-core VCO (Pitch, Fine Tune, Key Track, Glide, Linear FM with FM Ratio) > **Overtone** (blends the triangle toward 2nd/3rd-harmonic shapes) >
**Multiply** (smooth Lockhart-style wavefolder with Fold Offset, 2x oversampled) > **Dynamics** (vactrol low pass gate: amplitude and highs close together;
*Balance* VCA <-> LPG, *Vactrol Decay* sets the slow, level-dependent tail).
**Slope** = looping / one-shot rise-fall generator with Response (log - linear - exponential) and an end-of-cycle pulse. **Contour** = onset / sustain / decay envelope with Response.
Contour is normalled to Dynamics; everything else is patched in the matrix.

**Low pass gate (1.1.0):** the Dynamics row on the OSC page. *LPG Open* is a manual level while a key is down, *VCA <> LPG* blends a plain VCA (0) with the full gate (100), where the cutoff follows the vactrol from ~10 Hz to the top of the spectrum, and *Vactrol Decay* sets how slowly it closes. With the Contour at Sustain 60 % every note strikes bright and settles darker. Default Balance is now 100 and default Sustain 60.

## Patch matrix (virtual patch cables)
Six destinations - Pitch, Linear FM, Overtone, Multiply, Dynamics, Slope Rate - each take one source through an attenuverter (-100..+100):
Off, Slope, Contour, LFO, Random, Math, Key, Velocity, Mod Wheel, Slope EOC, Noise. *Voltage Math* = Math Input x Attenuverter + Offset.
Modulation runs at a 16-sample control rate (about 2.7 kHz): LFO/envelope-speed patches only. Linear FM uses an internal modulator at audio rate (FM Ratio).

## Clock, LFO, random
Clock follows the MPC transport (Host Sync) or runs internally; Clock Division sets the tick; Clock Trigger re-fires Slope / Contour on held notes.
LFO is free (Hz) or tempo-synced. Stepped Random takes a new value on the Clock, the Slope's end-of-cycle, or each note, with Slew.
**Hold a note** to hear the riff presets: the clock retriggers the envelopes and the random voltage steps the pitch through the Quantize scale.

## Randomize
RANDOMIZE (button on the MATRIX and CLOCK pages, also on its Q-Link) re-patches the voice. *Random Depth* 0-100 % sets how far it moves; the pitch it chooses snaps to the
Quantize scale (Chromatic, Minor, Major, Dorian, Phrygian, Pentatonic), as does any Random/LFO/Slope you patch into Pitch. The dynamics path is always left audible.

## Pages (Q-Link rows are banks of four)
F1: OSC / FOLD / DYNAMICS and SLOPE / CONTOUR - F2: PATCH MATRIX - F3: CLOCK / LFO / RANDOM.

## Honest notes
It is a musical emulation of the architecture, not a circuit-level model: the wavefolder is a smooth waveshaper, the vactrol is a two-rate non-linear envelope follower.
CPU about 1 % of a desktop core for 4 voices (host_sim); expect a few percent on the MPC. The skin generator is derived from GPL-3.0 helper code (see make_skin.py).
